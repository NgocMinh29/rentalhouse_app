/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.userapp;

/**
 *
 * @author NGUYEN MY NGAN
 */
public class LoginData {
    public static String khachid;
    public static String taikhoan;
    public static String matkhau;
}
